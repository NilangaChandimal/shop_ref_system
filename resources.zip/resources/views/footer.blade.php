<footer class="bg-gray-800 text-white py-4">
    <div class="container mx-auto text-center">
        <p class="text-sm">&copy; {{ date('Y') }} Nilanga Chandimal</p>
        <p class="text-sm">WhatsApp: <a href="https://wa.me/94770714587" class="text-blue-400 hover:underline" target="_blank">0770714587</a></p>
        <p class="text-sm">Email: <a href="mailto:nilangachandimal1111@gmail.com" class="text-blue-400 hover:underline">nilangachandimal1111@gmail.com</a></p>
    </div>
</footer>
