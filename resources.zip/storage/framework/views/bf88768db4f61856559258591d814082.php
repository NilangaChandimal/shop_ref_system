<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center px-6 py-6 bg-white shadow-sm rounded-lg">
            <h2 class="text-2xl font-bold text-gray-900 tracking-tight">
                <?php echo e(__('Sales Transactions')); ?>

            </h2>
            <div class="flex items-center space-x-2 bg-gradient-to-r from-emerald-50 to-white px-8 py-4 rounded-lg border border-emerald-100">
                <span class="text-gray-700 font-medium">Total Sales Value:</span>
                <span class="text-emerald-600 font-bold text-xl" id="totalSalesValue">Rs. 0.00</span>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12 bg-gray-50">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-lg rounded-xl">
                <div class="p-6">
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead>
                                <tr class="bg-gradient-to-r from-gray-50 to-white">
                                    <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">#</th>
                                    <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customer</th>
                                    <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Product</th>
                                    <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Qty</th>
                                    <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Value</th>
                                    <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Profit</th>
                                    <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Action</th>
                                </tr>
                            </thead>
                            <tbody id="salesTable" class="bg-white divide-y divide-gray-200">
                                <?php $__empty_1 = true; $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php
                                        $totalValue = $sale->products->sum(fn($product) => $product->pivot->quantity * $product->selling_price);
                                    ?>
                                    <tr class="hover:bg-blue-50 transition-colors duration-200">
                                        <td class="px-6 py-4 text-sm text-gray-500"><?php echo e($loop->iteration); ?></td>
                                        <td class="px-6 py-4 text-sm font-medium text-gray-900"><?php echo e($sale->customer->name); ?></td>
                                        <td class="px-6 py-4">
                                            <div class="space-y-2">
                                                <?php $__currentLoopData = $sale->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="text-sm">
                                                        <span class="text-gray-900 font-medium"><?php echo e($product->name); ?></span>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 text-sm font-medium text-gray-900">
                                            <?php $__currentLoopData = $sale->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div><?php echo e($product->pivot->quantity); ?></div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <td class="px-6 py-4 text-sm font-medium text-gray-900 total-value">
                                            Rs. <?php echo e(number_format($totalValue, 2)); ?>

                                        </td>
                                        <td class="px-6 py-4 text-sm font-medium text-emerald-600">
                                            Rs. <?php echo e(number_format($sale->products->sum(fn($product) => $product->pivot->quantity * ($product->selling_price - $product->original_price)), 2)); ?>

                                        </td>
                                        <td class="px-6 py-4 text-sm">
                                            <form action="<?php echo e(route('returns.create', $sale->id)); ?>" method="GET">
                                                <button type="submit"
                                                        class="inline-flex items-center px-4 py-2 text-sm font-medium rounded-lg text-white bg-blue-600 hover:bg-blue-700">
                                                    Return
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="px-6 py-4 text-center text-gray-500">No sales found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                            <tfoot>
                                <tr class="bg-gray-100">
                                    <td colspan="4" class="px-6 py-4 text-right font-bold">Total Sales Sum:</td>
                                    <td id="totalSalesSum" class="px-6 py-4 text-left font-bold text-emerald-600">Rs. 0.00</td>
                                    <td colspan="2"></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            let totalSalesSum = 0;

            // Select all "Total Value" cells
            const totalValueCells = document.querySelectorAll('.total-value');

            // Calculate total sum
            totalValueCells.forEach(cell => {
                const value = parseFloat(cell.textContent.replace('Rs.', '').replace(',', '').trim());
                if (!isNaN(value)) {
                    totalSalesSum += value;
                }
            });

            // Update total sales sum in footer and header
            document.getElementById('totalSalesSum').textContent = `Rs. ${totalSalesSum.toFixed(2)}`;
            document.getElementById('totalSalesValue').textContent = `Rs. ${totalSalesSum.toFixed(2)}`;
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH E:\4.2 SEM\laravel\spicy\resources\views\sales\index.blade.php ENDPATH**/ ?>