<div class="hidden sm:block">
    <div class="py-8">
        <div class="border-t border-gray-200"></div>
    </div>
</div>
<?php /**PATH E:\4.2 SEM\laravel\spicy\resources\views\components\section-border.blade.php ENDPATH**/ ?>