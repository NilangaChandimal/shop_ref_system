<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Edit Product')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg p-6">
                <form action="<?php echo e(route('products.update', $product)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <!-- Product Name -->
                    <div class="mb-4">
                        <label for="name" class="block text-gray-700 font-bold mb-2">Name:</label>
                        <input type="text" id="name" name="name" value="<?php echo e(old('name', $product->name)); ?>"
                            class="w-full border-gray-300 rounded-md shadow-sm" required>
                    </div>

                    <!-- Original Price -->
                    <div class="mb-4">
                        <label for="original_price" class="block text-gray-700 font-bold mb-2">Original Price:</label>
                        <input type="number" id="original_price" name="original_price" step="0.01"
                            value="<?php echo e(old('original_price', $product->original_price)); ?>"
                            class="w-full border-gray-300 rounded-md shadow-sm" required>
                    </div>

                    <!-- Displayed Price -->
                    <div class="mb-4">
                        <label for="displayed_price" class="block text-gray-700 font-bold mb-2">Displayed Price:</label>
                        <input type="number" id="displayed_price" name="displayed_price" step="0.01"
                            value="<?php echo e(old('displayed_price', $product->displayed_price)); ?>"
                            class="w-full border-gray-300 rounded-md shadow-sm" required>
                    </div>

                    <!-- Discount -->
                    <div class="mb-4">
                        <label for="discount" class="block text-gray-700 font-bold mb-2">Discount (%):</label>
                        <input type="number" id="discount" name="discount" step="0.01"
                            value="<?php echo e(old('discount', $product->discount)); ?>"
                            class="w-full border-gray-300 rounded-md shadow-sm" required>
                    </div>

                    <!-- Unit -->
                    <div class="mb-4">
                        <label for="unit" class="block text-gray-700 font-bold mb-2">Unit:</label>
                        <input type="text" id="unit" name="unit" value="<?php echo e(old('unit', $product->unit)); ?>"
                            class="w-full border-gray-300 rounded-md shadow-sm" required>
                    </div>

                    <!-- Quantity -->
                    <div class="mb-4">
                        <label for="quantity" class="block text-gray-700 font-bold mb-2">Quantity:</label>
                        <input type="number" id="quantity" name="quantity" value="<?php echo e(old('quantity', $product->quantity)); ?>"
                            class="w-full border-gray-300 rounded-md shadow-sm" required>
                    </div>

                    <!-- Image Upload -->
                    <?php if($product->image): ?>
                    <div class="mb-4">
                        <label class="block text-gray-700 font-bold mb-2">Current Image:</label>
                        <img src="<?php echo e(asset('storage/' . $product->image)); ?>"
     alt="Product Image"
     class="w-32 h-32 object-cover rounded-md">

                        
                        

                    </div>
                     <?php endif; ?>

                    <div class="mb-4">
                        <label for="image" class="block text-gray-700 font-bold mb-2">New Image:</label>
                        <input type="file" id="image" name="image" class="w-full border-gray-300 rounded-md shadow-sm">
                    </div>


                    <!-- Submit Button -->
                    <div>
                        <button type="submit"
                            class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                            Update Product
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH E:\4.2 SEM\laravel\spicy\resources\views\products\edit.blade.php ENDPATH**/ ?>